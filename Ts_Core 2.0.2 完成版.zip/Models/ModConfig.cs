﻿using StardewModdingAPI.Utilities;

namespace Ts_Core.Models
{
    /// <summary>
    /// T's Coreの設定です。
    /// </summary>
    public class ModConfig
    {
        //----------------------------------------
        // FarmHouse修正
        //----------------------------------------

        /// <summary>
        /// FarmHouseの配偶者部屋付近で
        /// カスタムタイルが上書きされる問題を修正します。
        /// </summary>
        public bool EnableSpouseRoomTileFix
        {
            get;
            set;
        } = false;

        //----------------------------------------
        // ショートカットパネル
        //----------------------------------------

        /// <summary>
        /// ショートカットパネルを表示するかどうか。
        /// </summary>
        public bool ShortcutPanelEnabled
        {
            get;
            set;
        } = true;

        /// <summary>
        /// ショートカットパネルが開いている時に、
        /// パネル外のクリック・タップで閉じるかどうか。
        /// </summary>
        public bool ShortcutPanelCloseOnOutsideClick
        {
            get;
            set;
        } = false;

        /// <summary>
        /// ショートカットパネルの表示位置です。
        /// Fixedは所持金UI基準、Freeは保存したオフセットを使用します。
        /// </summary>
        public string ShortcutPanelPositionMode
        {
            get;
            set;
        } = "Fixed";

        /// <summary>
        /// 自由配置時の既定位置からのX方向オフセットです。
        /// </summary>
        public int ShortcutPanelPositionX
        {
            get;
            set;
        } = 0;

        /// <summary>
        /// 自由配置時の既定位置からのY方向オフセットです。
        /// </summary>
        public int ShortcutPanelPositionY
        {
            get;
            set;
        } = 0;

        /// <summary>
        /// ショートカットパネルの開閉タブの
        /// 表示倍率です。
        /// 100～200で指定します。
        /// </summary>
        public int ShortcutPanelTabScale
        {
            get;
            set;
        } = 100;

        /// <summary>
        /// ショートカットパネル本体の
        /// 表示倍率です。
        /// 100～200で指定します。
        /// </summary>
        public int ShortcutPanelScale
        {
            get;
            set;
        } = 100;

        /// <summary>
        /// ショートカットパネルの開閉タブ背景の
        /// 不透明度です。
        /// 0～100で指定します。
        /// </summary>
        public int ShortcutPanelTabOpacity
        {
            get;
            set;
        } = 100;

        /// <summary>
        /// ショートカットパネル本体とスロット背景の
        /// 不透明度です。
        /// 0～100で指定します。
        /// </summary>
        public int ShortcutPanelOpacity
        {
            get;
            set;
        } = 100;

        /// <summary>
        /// 「現在の画面」のスクリーンショットに
        /// ゲームUIを含めるかどうか。
        /// </summary>
        public bool ScreenshotIncludeUi
        {
            get;
            set;
        } = true;

        /// <summary>
        /// 「現在の画面」のスクリーンショットに
        /// ショートカットパネルを含めるかどうか。
        /// </summary>
        public bool ScreenshotIncludeShortcutPanel
        {
            get;
            set;
        } = false;

        /// <summary>
        /// 「現在の画面」のスクリーンショットに
        /// マウスカーソルを含めるかどうか。
        /// </summary>
        public bool ScreenshotIncludeMouseCursor
        {
            get;
            set;
        } = false;

        //----------------------------------------
        // Time Skip
        //----------------------------------------

        /// <summary>
        /// Time Skipを実行するキーです。
        /// </summary>
        /// <summary>Terrain Features管理メニューを開くキーです。</summary>
        public KeybindList TerrainFeaturesMenuKey { get; set; } = new KeybindList(StardewModdingAPI.SButton.L);

        /// <summary>カスタム床材のバリアントを一つ前に戻すキーです。</summary>
        public KeybindList CustomFlooringPreviousVariantKey { get; set; } = new KeybindList(
            new Keybind(StardewModdingAPI.SButton.LeftShift, StardewModdingAPI.SButton.MouseLeft));

        /// <summary>カスタム床材の掲げる／しまう状態を切り替えるキーです。</summary>
        public KeybindList CustomFlooringStowKey { get; set; } = new KeybindList(
            new Keybind(StardewModdingAPI.SButton.RightShift, StardewModdingAPI.SButton.MouseLeft));

        /// <summary>設置済みのカスタム床材の位置を表示するキーです。</summary>
        public KeybindList CustomFlooringIdentifyKey { get; set; } = new KeybindList(StardewModdingAPI.SButton.F8);

        public KeybindList TimeSkipKey
        {
            get;
            set;
        } = new KeybindList();

        /// <summary>
        /// Time Skipの移動先時刻です。
        /// </summary>
        public int TimeSkipTime
        {
            get;
            set;
        } = 1000;

        /// <summary>
        /// Time Skip (Duration)を実行するキーです。
        /// </summary>
        public KeybindList TimeSkipDurationKey
        {
            get;
            set;
        } = new KeybindList();

        /// <summary>
        /// Time Skip (Duration)で進める時間です。
        /// 分単位で指定します。
        /// </summary>
        public int TimeSkipDuration
        {
            get;
            set;
        } = 60;

        /// <summary>
        /// Time Skip中のNPC Schedule処理速度です。
        /// </summary>
        public TimeSkipSpeed TimeSkipSpeed
        {
            get;
            set;
        } = TimeSkipSpeed.Normal;

        /// <summary>
        /// Time Skip完了時の通知設定です。
        /// </summary>
        public bool TimeSkipNotification
        {
            get;
            set;
        } = true;
    }
}
