﻿using HarmonyLib;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Netcode;
using StardewValley;
using StardewValley.Buildings;
using StardewValley.Delegates;
using StardewValley.Objects;
using Ts_Core.Models.BuildingRelated;

namespace Ts_Core.Services.BuildingRelated
{
    /// <summary>
    /// TsCoreの条件付きBuilding DrawLayerを描画するサービスです。
    /// </summary>
    public static class BuildingDrawLayerService
    {
        //----------------------------------------
        // Building内部Field
        //----------------------------------------

        /// <summary>
        /// Buildingの新規建設アニメーションタイマーです。
        /// </summary>
        private static readonly AccessTools.FieldRef<Building, NetInt>
            NewConstructionTimer =
                AccessTools.FieldRefAccess<Building, NetInt>(
                    "newConstructionTimer");

        //----------------------------------------
        // 新規建設アニメーション判定
        //----------------------------------------

        /// <summary>
        /// Buildingが新規建設アニメーション中か取得します。
        /// </summary>
        internal static bool IsNewConstruction(
            Building building)
        {
            return NewConstructionTimer(
                building).Value > 0;
        }

        //----------------------------------------
        // DrawLayer描画
        //----------------------------------------

        /// <summary>
        /// 指定した建物のTsCore DrawLayerを描画します。
        /// </summary>
        public static void DrawLayers(
            Building building,
            SpriteBatch spriteBatch,
            BuildingProviderModel provider,
            IReadOnlyList<BuildingDrawLayerModel> drawLayers,
            bool drawInBackground)
        {
            if (drawLayers.Count == 0)
                return;

            if (building.isMoving)
                return;

            if (building.daysOfConstructionLeft.Value > 0)
                return;

            GameLocation? location =
                building.GetParentLocation();

            if (location == null)
                return;

            //----------------------------------------
            // 建物描画用基本値
            //----------------------------------------

            Rectangle mainSourceRect =
                building.getSourceRect();

            Vector2 drawOrigin =
                new(
                    0f,
                    mainSourceRect.Height);

            Vector2 drawPosition =
                new(
                    building.tileX.Value * 64,
                    building.tileY.Value * 64
                        + building.tilesHigh.Value * 64);

            float baseSortY =
                (building.tileY.Value
                    + building.tilesHigh.Value)
                * 64f;

            //----------------------------------------
            // DrawLayer一覧
            //----------------------------------------

            foreach (BuildingDrawLayerModel drawLayer in drawLayers)
            {
                //----------------------------------------
                // 個別DrawLayer有効判定
                //----------------------------------------

                if (!drawLayer.Enabled)
                {
                    continue;
                }

                if (!BuildingProviderService.IsEnabledField(
                        provider,
                        drawLayer.EnabledField))
                {
                    continue;
                }

                //----------------------------------------
                // Background / Foreground判定
                //----------------------------------------

                // 床材の上に置く背景レイヤーは通常描画側で処理します。
                bool useBackgroundPass =
                    drawLayer.DrawInBackground
                    && !drawLayer.DrawAboveFlooring;

                if (useBackgroundPass != drawInBackground)
                    continue;

                //----------------------------------------
                // Condition判定
                //----------------------------------------

                if (!CheckCondition(
                        drawLayer.Condition,
                        location))
                {
                    continue;
                }

                //----------------------------------------
                // Chest条件
                //----------------------------------------

                if (!string.IsNullOrWhiteSpace(
                        drawLayer.OnlyDrawIfChestHasContents))
                {
                    Chest? chest =
                        building.GetBuildingChest(
                            drawLayer.OnlyDrawIfChestHasContents);

                    if (chest == null || chest.isEmpty())
                        continue;
                }

                //----------------------------------------
                // SourceRect
                //----------------------------------------

                Rectangle sourceRect =
                    GetSourceRect(
                        drawLayer, building);

                // BuildingDataのSeasonOffset等を適用
                sourceRect =
                    building.ApplySourceRectOffsets(
                        sourceRect);

                //----------------------------------------
                // Texture
                //----------------------------------------

                Texture2D layerTexture;

                if (!string.IsNullOrWhiteSpace(
                        drawLayer.Texture))
                {
                    layerTexture =
                        Game1.content.Load<Texture2D>(
                            drawLayer.Texture);
                }
                else
                {
                    layerTexture =
                        building.texture.Value;
                }

                //----------------------------------------
                // Animal Door Offset
                //----------------------------------------

                Vector2 drawOffset =
                    Vector2.Zero;

                if (drawLayer.AnimalDoorOffset != Vector2.Zero)
                {
                    drawOffset =
                        new Vector2(
                            drawLayer.AnimalDoorOffset.X
                                * building.animalDoorOpenAmount.Value,
                            drawLayer.AnimalDoorOffset.Y
                                * building.animalDoorOpenAmount.Value);
                }

                //----------------------------------------
                // DrawPosition
                //----------------------------------------

                Vector2 position =
                    Game1.GlobalToLocal(
                        Game1.viewport,
                        drawPosition
                        + (drawOffset
                           - drawOrigin
                           + drawLayer.DrawPosition)
                        * 4f);

                //----------------------------------------
                // SortY
                //----------------------------------------

                float sortY;

                if (drawInBackground)
                {
                    sortY = 0f;
                }
                else if (drawLayer.DrawInBackground
                    && drawLayer.DrawAboveFlooring)
                {
                    // 床材より上、建物本体より下の描画深度。
                    sortY = 0.00002f;
                }
                else
                {
                    sortY =
                        baseSortY
                        - drawLayer.SortTileOffset * 64f;

                    sortY += 1f;
                    sortY /= 10000f;
                }

                //----------------------------------------
                // Draw
                //----------------------------------------

                spriteBatch.Draw(
                    layerTexture,
                    position,
                    sourceRect,
                    building.color * building.alpha,
                    0f,
                    Vector2.Zero,
                    4f,
                    SpriteEffects.None,
                    sortY);
            }
        }

        //----------------------------------------
        // 新規建設アニメーションDrawLayer描画
        //----------------------------------------

        /// <summary>
        /// 新規建設アニメーション中のBuildingに
        /// TsCore DrawLayerを下から上へ段階的に描画します。
        /// </summary>
        internal static void DrawLayersInConstruction(
            Building building,
            SpriteBatch spriteBatch)
        {
            //----------------------------------------
            // 描画対象確認
            //----------------------------------------

            if (building.isMoving)
                return;

            if (building.daysOfConstructionLeft.Value > 0)
                return;

            NetInt newConstructionTimer =
                NewConstructionTimer(
                    building);

            if (newConstructionTimer.Value <= 0)
                return;

            GameLocation? location =
                building.GetParentLocation();

            if (location == null)
                return;

            //----------------------------------------
            // Provider取得
            //----------------------------------------

            IReadOnlyList<BuildingProviderModel> providers =
                BuildingProviderService.GetProvidersForBuilding(
                    building.buildingType.Value);

            if (providers.Count == 0)
                return;

            //----------------------------------------
            // バニラ建設アニメーションと同じ基本値
            //----------------------------------------

            Rectangle mainSourceRect =
                building.getSourceRect();

            float drawPercentageReal =
                (2000f - newConstructionTimer.Value)
                / 2000f;

            int yPos =
                (int)(
                    mainSourceRect.Height
                    * 4f
                    * (1f - drawPercentageReal));

            Vector2 drawOrigin =
                new(
                    0f,
                    mainSourceRect.Height);

            Vector2 drawPosition =
                new(
                    building.tileX.Value * 64,
                    building.tileY.Value * 64
                        + building.tilesHigh.Value * 64);

            float baseSortY =
                (building.tileY.Value
                    + building.tilesHigh.Value)
                * 64f;

            //----------------------------------------
            // Provider一覧
            //----------------------------------------

            foreach (BuildingProviderModel provider in providers)
            {
                //----------------------------------------
                // DrawLayers全体
                //----------------------------------------

                if (!BuildingProviderService.AreDrawLayersEnabled(
                        provider))
                {
                    continue;
                }

                //----------------------------------------
                // DrawLayer一覧
                //----------------------------------------

                foreach (BuildingDrawLayerModel drawLayer
                         in provider.DrawLayers)
                {
                    //----------------------------------------
                    // 個別DrawLayer有効判定
                    //----------------------------------------

                    if (!drawLayer.Enabled)
                    {
                        continue;
                    }

                    if (!BuildingProviderService.IsEnabledField(
                            provider,
                            drawLayer.EnabledField))
                    {
                        continue;
                    }

                    //----------------------------------------
                    // Condition判定
                    //----------------------------------------

                    if (!CheckCondition(
                            drawLayer.Condition,
                            location))
                    {
                        continue;
                    }

                    //----------------------------------------
                    // Chest条件
                    //----------------------------------------
                    //
                    // バニラdrawInConstructionと同様に、
                    // Chest条件付きDrawLayerは建設中に描画しません。
                    //----------------------------------------

                    if (!string.IsNullOrWhiteSpace(
                            drawLayer.OnlyDrawIfChestHasContents))
                    {
                        continue;
                    }

                    //----------------------------------------
                    // SortY
                    //----------------------------------------
                    //
                    // 建設中はDrawInBackgroundを区別せず、
                    // バニラdrawInConstructionと同じSortYを使用します。
                    //----------------------------------------

                    float sortY =
                        baseSortY
                        - drawLayer.SortTileOffset * 64f;

                    sortY += 1f;
                    sortY /= 10000f;

                    //----------------------------------------
                    // SourceRect
                    //----------------------------------------

                    Rectangle sourceRect =
                        GetSourceRect(
                            drawLayer, building);

                    sourceRect =
                        building.ApplySourceRectOffsets(
                            sourceRect);

                    //----------------------------------------
                    // 建設進行位置
                    //----------------------------------------
                    //
                    // バニラBuilding.drawInConstructionと同じ計算。
                    //----------------------------------------

                    float cutoffPixels =
                        (float)(yPos / 4)
                        - drawLayer.DrawPosition.Y;

                    //----------------------------------------
                    // まだDrawLayerの位置まで建設されていない
                    //----------------------------------------

                    if (cutoffPixels > sourceRect.Height)
                        continue;

                    //----------------------------------------
                    // Animal Door Offset
                    //----------------------------------------

                    Vector2 drawOffset =
                        Vector2.Zero;

                    if (drawLayer.AnimalDoorOffset != Vector2.Zero)
                    {
                        drawOffset =
                            new Vector2(
                                drawLayer.AnimalDoorOffset.X
                                    * building.animalDoorOpenAmount.Value,
                                drawLayer.AnimalDoorOffset.Y
                                    * building.animalDoorOpenAmount.Value);
                    }

                    //----------------------------------------
                    // 上側を切り取る
                    //----------------------------------------

                    if (cutoffPixels > 0f)
                    {
                        drawOffset.Y +=
                            cutoffPixels;

                        sourceRect.Y +=
                            (int)cutoffPixels;

                        sourceRect.Height -=
                            (int)cutoffPixels;
                    }

                    //----------------------------------------
                    // Texture
                    //----------------------------------------

                    Texture2D layerTexture;

                    if (!string.IsNullOrWhiteSpace(
                            drawLayer.Texture))
                    {
                        layerTexture =
                            Game1.content.Load<Texture2D>(
                                drawLayer.Texture);
                    }
                    else
                    {
                        layerTexture =
                            building.texture.Value;
                    }

                    //----------------------------------------
                    // DrawPosition
                    //----------------------------------------

                    Vector2 position =
                        Game1.GlobalToLocal(
                            Game1.viewport,
                            drawPosition
                            + (drawOffset
                               - drawOrigin
                               + drawLayer.DrawPosition)
                            * 4f);

                    //----------------------------------------
                    // 描画
                    //----------------------------------------

                    spriteBatch.Draw(
                        layerTexture,
                        position,
                        sourceRect,
                        building.color * building.alpha,
                        0f,
                        Vector2.Zero,
                        4f,
                        SpriteEffects.None,
                        sortY);
                }
            }
        }

        //----------------------------------------
        // Condition判定
        //----------------------------------------

        /// <summary>
        /// Game State Query条件を評価します。
        /// </summary>
        private static bool CheckCondition(
            string? condition,
            GameLocation location)
        {
            if (string.IsNullOrWhiteSpace(condition))
                return true;

            GameStateQueryContext context =
                new(
                    location,
                    Game1.player,
                    null,
                    null,
                    Game1.random);

            return GameStateQuery.CheckConditions(
                condition,
                context);
        }

        //----------------------------------------
        // SourceRect取得
        //----------------------------------------

        /// <summary>
        /// DrawLayerの現在のSourceRectを取得します。
        /// </summary>
        private static Rectangle GetSourceRect(
            BuildingDrawLayerModel drawLayer,
            Building building)
        {
            Rectangle sourceRect =
                drawLayer.SourceRect;

            //----------------------------------------
            // アニメーションなし
            //----------------------------------------

            if (drawLayer.FrameCount <= 1)
                return sourceRect;

            //----------------------------------------
            // フレーム数
            //----------------------------------------

            int frameCount =
                Math.Max(
                    1,
                    drawLayer.FrameCount);

            //----------------------------------------
            // 現在時刻
            //----------------------------------------

            long time =
                (long)Game1.currentGameTime
                    .TotalGameTime
                    .TotalMilliseconds;

            //----------------------------------------
            // 1ループ分の総時間
            //----------------------------------------

            int totalDuration = 0;

            for (int i = 0;
                 i < frameCount;
                 i++)
            {
                totalDuration +=
                    drawLayer.GetFrameDuration(
                        i);
            }

            //----------------------------------------
            // 不正値対策
            //----------------------------------------

            if (totalDuration <= 0)
                totalDuration = 1;

            //----------------------------------------
            // 現在フレーム
            //----------------------------------------

            // 建物の位置とレイヤーIDから固定のずれ幅を生成します。
            // ゲーム再起動後も同じ位置の建物は同じタイミングになります。
            if (drawLayer.RandomStartFrame
                && drawLayer.RandomStartIntervalMs > 0)
            {
                int interval = drawLayer.RandomStartIntervalMs;
                int slotCount = (totalDuration - 1) / interval + 1;

                uint hash = 2166136261;
                unchecked
                {
                    hash = (hash ^ (uint)building.tileX.Value) * 16777619;
                    hash = (hash ^ (uint)building.tileY.Value) * 16777619;
                    foreach (char c in building.buildingType.Value)
                        hash = (hash ^ c) * 16777619;
                    foreach (char c in drawLayer.Id)
                        hash = (hash ^ c) * 16777619;
                }

                time += (long)(hash % (uint)slotCount) * interval;
            }

            int animationTime =
                (int)(time % totalDuration);

            int frame = 0;

            int elapsed = 0;

            for (int i = 0;
                 i < frameCount;
                 i++)
            {
                elapsed +=
                    drawLayer.GetFrameDuration(
                        i);

                if (animationTime < elapsed)
                {
                    frame = i;
                    break;
                }
            }

            //----------------------------------------
            // SourceRect移動
            //----------------------------------------

            if (drawLayer.FramesPerRow < 0)
            {
                sourceRect.X +=
                    sourceRect.Width
                    * frame;
            }
            else
            {
                int framesPerRow =
                    Math.Max(
                        1,
                        drawLayer.FramesPerRow);

                sourceRect.X +=
                    sourceRect.Width
                    * (frame % framesPerRow);

                sourceRect.Y +=
                    sourceRect.Height
                    * (frame / framesPerRow);
            }

            return sourceRect;
        }

        //----------------------------------------
        // BuildingからDrawLayer描画
        //----------------------------------------

        /// <summary>
        /// 指定した建物に登録されているTsCore DrawLayerを描画します。
        /// </summary>
        public static void DrawLayers(
            Building building,
            SpriteBatch spriteBatch,
            bool drawInBackground)
        {
            IReadOnlyList<BuildingProviderModel> providers =
                BuildingProviderService.GetProvidersForBuilding(
                    building.buildingType.Value);

            foreach (BuildingProviderModel provider in providers)
            {
                //----------------------------------------
                // DrawLayers全体
                //----------------------------------------

                if (!BuildingProviderService.AreDrawLayersEnabled(
                        provider))
                {
                    continue;
                }

                DrawLayers(
                    building,
                    spriteBatch,
                    provider,
                    provider.DrawLayers,
                    drawInBackground);
            }
        }

        //----------------------------------------
        // 建設メニュー用DrawLayer描画
        //----------------------------------------

        /// <summary>
        /// 建設メニューのBuildingプレビューに
        /// TsCore DrawLayerを描画します。
        /// </summary>
        public static void DrawLayersInMenu(
            Building building,
            SpriteBatch spriteBatch,
            int x,
            int y,
            GameLocation targetLocation)
        {
            IReadOnlyList<BuildingProviderModel> providers =
                BuildingProviderService.GetProvidersForBuilding(
                    building.buildingType.Value);

            if (providers.Count == 0)
                return;

            var buildingData =
                building.GetData();

            //----------------------------------------
            // BuildingData.DrawOffset
            //----------------------------------------

            if (buildingData != null)
            {
                x +=
                    (int)(buildingData.DrawOffset.X * 4f);

                y +=
                    (int)(buildingData.DrawOffset.Y * 4f);
            }

            //----------------------------------------
            // 基本SortY
            //----------------------------------------

            float baseSortY =
                building.tilesHigh.Value * 64f;

            //----------------------------------------
            // Provider一覧
            //----------------------------------------

            foreach (BuildingProviderModel provider in providers)
            {
                //----------------------------------------
                // DrawLayers全体
                //----------------------------------------

                if (!BuildingProviderService.AreDrawLayersEnabled(
                        provider))
                {
                    continue;
                }

                //----------------------------------------
                // DrawLayer一覧
                //----------------------------------------

                foreach (BuildingDrawLayerModel drawLayer
                         in provider.DrawLayers)
                {
                    //----------------------------------------
                    // 個別DrawLayer
                    //----------------------------------------

                    if (!drawLayer.Enabled)
                    {
                        continue;
                    }

                    if (!BuildingProviderService.IsEnabledField(
                            provider,
                            drawLayer.EnabledField))
                    {
                        continue;
                    }

                    //----------------------------------------
                    // Condition
                    //----------------------------------------

                    if (!CheckCondition(
                            drawLayer.Condition,
                            targetLocation))
                    {
                        continue;
                    }

                    //----------------------------------------
                    // Chest条件
                    //----------------------------------------
                    //
                    // 建設メニューには実際のChestが存在しないため、
                    // バニラdrawInMenuと同様に表示しません。
                    //----------------------------------------

                    if (!string.IsNullOrWhiteSpace(
                            drawLayer.OnlyDrawIfChestHasContents))
                    {
                        continue;
                    }

                    //----------------------------------------
                    // SortY
                    //----------------------------------------

                    float sortY =
                        baseSortY
                        - drawLayer.SortTileOffset * 64f;

                    sortY += 1f;

                    if (drawLayer.DrawInBackground)
                    {
                        sortY = 0f;
                    }

                    sortY /= 10000f;

                    //----------------------------------------
                    // SourceRect
                    //----------------------------------------

                    Rectangle sourceRect =
                        GetSourceRect(
                            drawLayer, building);

                    sourceRect =
                        building.ApplySourceRectOffsets(
                            sourceRect);

                    //----------------------------------------
                    // Texture
                    //----------------------------------------

                    Texture2D layerTexture =
                        building.texture.Value;

                    if (!string.IsNullOrWhiteSpace(
                            drawLayer.Texture))
                    {
                        layerTexture =
                            Game1.content.Load<Texture2D>(
                                drawLayer.Texture);
                    }

                    //----------------------------------------
                    // 描画
                    //----------------------------------------

                    spriteBatch.Draw(
                        layerTexture,
                        new Vector2(x, y)
                            + drawLayer.DrawPosition * 4f,
                        sourceRect,
                        Color.White,
                        0f,
                        Vector2.Zero,
                        4f,
                        SpriteEffects.None,
                        sortY);
                }
            }
        }
    }
}