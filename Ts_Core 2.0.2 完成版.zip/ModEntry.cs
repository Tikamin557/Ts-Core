﻿using HarmonyLib;
using StardewModdingAPI;
using StardewModdingAPI.Events;
using Ts_Core.Actions;
using Ts_Core.Api;
using Ts_Core.Debug;
using Ts_Core.Initializers;
using Ts_Core.Interfaces;
using Ts_Core.Models;
using Ts_Core.Patches;
using Ts_Core.Patches.BigCraftableRelated;
using Ts_Core.Providers;
using Ts_Core.Services;
using Ts_Core.Services.BigCraftableRelated;
using Ts_Core.Services.BuildingRelated;
using Ts_Core.Services.ContentPatcherRelated;
using Ts_Core.Services.DebugSupport;
using Ts_Core.Services.DialogueRelated;
using Ts_Core.Services.EventRelated;
using Ts_Core.Services.FarmhouseFixes;
using Ts_Core.Services.GameStateQueryRelated;
using Ts_Core.Services.GenericModConfigMenuRelated;
using Ts_Core.Services.Location;
using Ts_Core.Services.LocationFixes;
using Ts_Core.Services.MapRelated.PostRenovation;
using Ts_Core.Services.MapRelated.TimedExit;
using Ts_Core.Services.MapRelated.TsCoreAlwaysFront;
using Ts_Core.Services.MapRelated.TsCoreAmbientLight;
using Ts_Core.Services.MapRelated.TsCoreDecoratableCellar;
using Ts_Core.Services.MapRelated.TsCoreGreenhouse;
using Ts_Core.Services.MapRelated.TsCoreOutOfBoundsMask;
using Ts_Core.Services.Migration;
using Ts_Core.Services.Notification;
using Ts_Core.Services.PolyamorySweetRoomsRelated;
using Ts_Core.Services.Relationship;
using Ts_Core.Services.ScreenshotRelated;
using Ts_Core.Services.ShortcutPanelRelated;
using Ts_Core.Services.TerrainFeaturesRelated;
using Ts_Core.Services.WarpRelated;
using Ts_Core.Tokens;

namespace Ts_Core
{
    /// <summary>
    /// Ts_Coreのエントリーポイントです。
    /// 各サービス・トークン・アクション・デバッグ機能を初期化します。
    /// </summary>
    public class ModEntry : Mod
    {
        //----------------------------------------
        // 外部API対応優先順位
        //----------------------------------------

        /// <summary>
        /// 外部API対応している結婚Modの優先順位。
        /// 上から順に優先して使用される。
        /// </summary>
        private static readonly string[] SupportedMarriageApis =
        {
            "ApryllForever.PolyamorySweetLove",
            "aedenthorn.FreeLove"
        };

        //----------------------------------------
        // 設定
        //----------------------------------------

        internal static ModConfig Config
        {
            get;
            private set;
        } = new();

        //----------------------------------------
        // サービス
        //----------------------------------------

        private PartnerService service = null!;
        private IPartnerProvider provider = null!;
        private Harmony? harmony;

        //----------------------------------------
        // Content Patcher
        //----------------------------------------

        /// <summary>
        /// GameLaunched後にGMCM表示条件を
        /// 1回だけ反映するためのフラグ。
        /// </summary>
        private bool refreshContentPatcherConfigMenus;

        /// <summary>
        /// GameLaunched以前の言語変更でCPの未初期化データを参照しないためのフラグ。
        /// </summary>
        private bool hasGameLaunched;

        /// <summary>
        /// Content Patcherの起動直後のToken/i18n初期化完了を待つためのtick数。
        /// </summary>
        private int refreshContentPatcherConfigMenusDelayTicks;

        //----------------------------------------
        // エントリーポイント
        //----------------------------------------

        /// <summary>
        /// Modの起動時に呼ばれ、設定の読み込み・サービス初期化・各システムとイベントの登録を行います。
        /// </summary>
        public override void Entry(
            IModHelper helper)
        {
            //----------------------------------------
            // 設定読み込み
            //----------------------------------------

            Config =
                helper.ReadConfig<ModConfig>();

            harmony =
                new Harmony(
                    ModManifest.UniqueID);

            // イベント中のみのタイル置き換え（AnimatedTile対応）
            EventMapTileService.Initialize(helper, Monitor);

            //----------------------------------------
            // Harmonyパッチ
            //----------------------------------------

            // Cellar内でバニラの壁紙・床材アイテムを使用可能にします。
            TsCoreDecoratableCellarItemPatch.Apply(harmony, Monitor);

            // クラフト・料理レシピの素材不要指定に対応
            NullRecipeIngredientsPatch.Apply(harmony, Monitor, helper.Translation);

            // PC版クラフト・料理レシピの専用ページ切り替え
            CustomRecipePageCraftingPagePatch.Apply(harmony, Monitor, helper.Translation);
            CustomRecipePageBetterCraftingPatch.Apply(harmony, Monitor, helper.Translation, helper);

            // Stardew Valley標準のWarp警告を抑制
            WarpWarningPatch.Apply(
                harmony);

            // タイルのワープTouchActionを接触時に起動
            InstantTouchWarpPatch.Apply(harmony);

            // BuildingのHumanDoorタッチ入室とクリック入室制御
            BuildingHumanDoorTouchWarpPatch.Apply(harmony);

            // Warp暗転オーバーレイを最終描画
            WarpBlackoutOverlayPatch.Apply(
                harmony);

            // Stardew Valley標準のレイントーテムの不具合を修正
            RainTotemPatch.Apply(
                harmony,
                Monitor);

            // FarmHouse配偶者部屋の不要タイルを修正
            SpouseRoomTileFixPatch.Apply(
                harmony);

            // CP等から読み込まれた配偶者部屋の
            // 窓・照明の昼夜切り替えを補完
            SpouseRoomWindowFixPatch.Apply(
                harmony);

            // FarmHouseのRenovation適用後に
            // Map Patchを適用
            PostRenovationPatch.Apply(
                harmony);

            // TsCoreGreenhouse Map Propertyを
            // Stardew Valley本体の温室処理へ適用
            TsCoreGreenhousePatch.Apply(
                harmony);

            // TsCoreAmbientLight = Farmhouse のLocationへ
            // Vanilla FarmHouseと同じAmbient Light処理を適用
            TsCoreAmbientLightPatch.Apply(
                harmony);

            // FarmHouse配偶者部屋の特殊表示物を
            // T's Core Option設定に応じて調整
            SpouseRoomVisualFixPatch.Apply(
                harmony);

            // Polyamory Sweet Roomsで
            // 存在しない配偶者の部屋生成をスキップ
            PolyamorySweetRoomsCompatibilityPatch.Apply(
                harmony,
                helper,
                Monitor);

            // Buildingから開始されたDialogueの
            // 操作元Buildingを追跡
            DialogueBuildingContext.Apply(
                harmony);

            // FarmHouseの通常玄関からのWarpを追跡
            FarmHouseEntranceTracker.Apply(
                harmony);

            // FarmHouseへのWarp時に指定座標が入口へ
            // 変更される問題を修正
            FarmHouseWarpFixPatch.Apply(
                harmony);

            // 建物移動・撤去時にBuilding Lightを更新
            BuildingLightPatch.Apply(
                harmony);

            // Buildingに条件付きDrawLayerを追加
            BuildingDrawLayerPatch.Apply(
                harmony);

            // Buildingの建築Location制限を適用
            BuildingLocationRestrictionPatch.Apply(
                harmony);

            // BigCraftable Extensionの
            // 設置範囲を適用
            BigCraftablePlacementPatch.Apply(
                harmony);

            // BigCraftable Extensionの
            // 追加Collision範囲を占有タイルとして扱う
            BigCraftableOccupancyPatch.Apply(
                harmony);

            // BigCraftable Extensionの
            // 追加Collision範囲を移動Collisionに適用
            BigCraftableMovementCollisionPatch.Apply(
                harmony);

            // BigCraftable Extensionの追加Collisionと
            // PlayerPassableTilesをAndroid Tap-to-Moveへ反映
            BigCraftableAndroidTapToMovePatch.Apply(
                harmony,
                Monitor);

            // BigCraftable Extensionの
            // TilePropertyを有効化
            BigCraftableTilePropertyPatch.Apply(
                harmony);

            // BigCraftable Extensionの
            // TileActionを有効化
            BigCraftableActionPatch.Apply(
                harmony);

            // BigCraftable Extensionの
            // Sleep時のFarmer表示を補完
            BigCraftableSleepActionPatch.Apply(
                harmony);

            // BigCraftable Extensionの
            // 継続寝床での起床判定を補完
            BigCraftableSleepWakeUpPatch.Apply(
                harmony);

            // BigCraftable Extensionの
            // Action / Idle Wobbleを有効化
            MachineShouldWobblePatch.Apply(
                harmony);

            // BigCraftable Extensionの
            // Texture / Animation / DrawLayerを有効化
            MachineAnimationTexturePatch.Apply(
                harmony,
                Monitor);

            // BigCraftable Extensionの
            // Texture Size / DrawLayerをMenu描画に適用
            BigCraftableMenuDrawPatch.Apply(
                harmony);

            // BigCraftable Extensionの
            // Texture Size / DrawLayerをCrafting Recipe描画に適用
            BigCraftableCraftingRecipeDrawPatch.Apply(
                harmony);

            // BigCraftable Extensionの
            // Crafting Page描画位置を中央に補正
            BigCraftableCraftingPageDrawPatch.Apply(
                harmony);

            // BigCraftable Extensionの
            // Texture Size / DrawLayerをCrafting Page描画に適用
            BigCraftableCraftingPagePatch.Apply(
                harmony);

            // BigCraftable Extensionの
            // 手持ち状態でのTexture / DrawLayerを適用
            BigCraftableHeldDrawPatch.Apply(
                harmony);

            // BigCraftable Extensionの
            // 拡張Collision範囲へのTool Actionを適用
            BigCraftableToolActionPatch.Apply(
                harmony);

            // BigCraftable Extensionの
            // 仮想Collision範囲からの素手回収を有効化
            BigCraftableBareHandRemovalPatch.Apply(
                harmony);

            // BigCraftable Extensionの
            // 拡張Texture用描画範囲を有効化
            BigCraftableDrawCullingPatch.Apply(
                harmony,
                Monitor);

            // BigCraftable Extensionの
            // 拡張Texture用描画範囲を有効化
            // (Ultra Smooth Mod導入時のみ)
            BigCraftableUltraSmoothCompatibilityPatch.Apply(
                harmony,
                Monitor);

            // Custom Flooring（バニラのFlooringを拡張）
            CustomFlooringService.Initialize(helper, Monitor, harmony);
            CustomFlooringObjectTextureService.Initialize(helper, Monitor);

            //----------------------------------------
            // 初期化
            //----------------------------------------

            InitializeServices(
                helper);

            RegisterSystems(
                helper);

            RegisterEvents(
                helper);

            NotificationThemeManager.Initialize(
                Helper,
                Monitor);

            NotificationService.Initialize(
                helper);

            // ショートカットパネルより先に初期化し、
            // パネル描画前のCurrent Screenを取得できるようにする。
            ScreenshotService.Initialize(
                helper,
                Monitor);

            ShortcutPanelService.Initialize(
                helper,
                Monitor);
        }

        //----------------------------------------
        // 外部API
        //----------------------------------------

        /// <summary>
        /// 外部Modへ公開する
        /// T's Core APIを返します。
        /// </summary>
        public override object GetApi()
        {
            return new TsCoreApi();
        }

        //----------------------------------------
        // サービス初期化
        //----------------------------------------

        /// <summary>
        /// T's Coreで使用する各サービスを初期化します。
        /// </summary>
        private void InitializeServices(
            IModHelper helper)
        {
            LocationTracker.Initialize(
                helper);

            //----------------------------------------
            // 使用可能な結婚APIを検索
            //----------------------------------------

            string? modId =
                SupportedMarriageApis
                    .FirstOrDefault(
                        id =>
                            helper.ModRegistry
                                .IsLoaded(id));

            provider =
                modId != null
                    ? new ApiMarriageProvider(
                        helper,
                        modId)
                    : new VanillaProvider();

            service =
                new PartnerService(
                    provider);

            //----------------------------------------
            // PSR Room Presets
            //----------------------------------------

            // PSR Content Packのcontent.json読み書き
            PsrRoomContentService.Initialize(
                helper,
                Monitor);

            // PSR設定画面の利用可否判定・表示
            PsrRoomPresetUiService.Initialize(
                helper.Translation,
                service,
                helper.ModRegistry);
        }

        //----------------------------------------
        // システム登録
        //----------------------------------------

        /// <summary>
        /// T's Coreが提供する各機能やシステムを登録します。
        /// </summary>
        private void RegisterSystems(
            IModHelper helper)
        {
            //----------------------------------------
            // デバッグコマンド登録
            //----------------------------------------

            DebugCommandRegistry.Register(
                helper,
                Monitor,
                service,
                provider);

            //----------------------------------------
            // Time Skip初期化
            //----------------------------------------

            TimeSkipService.Initialize(
                Helper);

            TerrainFeaturesMenuService.Initialize(Helper, Monitor);
            TerrainFeaturesMenuService.ApplyOriginalModCompatibility(harmony!, helper.ModRegistry);

            //----------------------------------------
            // Machine Texture / Animation初期化
            //----------------------------------------

            MachineAnimationTextureService.Initialize(
                Monitor);

            BigCraftableExtensionTextureService.Initialize(
                Monitor);

            //----------------------------------------
            // アクション登録
            //----------------------------------------

            ActionRegistry.Register();

            //----------------------------------------
            // Game State Query登録
            //----------------------------------------

            GameStateQueryService.Register();

            //----------------------------------------
            // BigCraftable Extension
            // Sleep TileAction登録
            //----------------------------------------

            BigCraftableSleepActionService.Register();

            //----------------------------------------
            // BigCraftable Extension
            // Sleep継続寝床サービス初期化
            //----------------------------------------

            BigCraftableSleepPersistenceService.Initialize(
                helper);

            //----------------------------------------
            // Warp Providerサービス初期化
            //----------------------------------------

            WarpProviderService.Initialize(
                Monitor);

            //----------------------------------------
            // Warpサービス初期化
            //----------------------------------------

            WarpService.Initialize(
                Monitor);

            //----------------------------------------
            // Tile Property Warpサービス初期化
            //----------------------------------------

            TilePropertyWarpService.Initialize(
                Monitor);

            //----------------------------------------
            // TsCoreAlwaysFrontレイヤー初期化
            //----------------------------------------

            TsCoreAlwaysFrontService.Initialize(
                helper);

            //----------------------------------------
            // Map範囲外マスク初期化
            //----------------------------------------

            TsCoreOutOfBoundsMaskService.Initialize(
                helper);

            //----------------------------------------
            // Post Renovation Patch初期化
            //----------------------------------------

            PostRenovationPatchService.Initialize(
                helper,
                Monitor);

            //----------------------------------------
            // Timed Exitサービス初期化
            //----------------------------------------

            TimedExitService.Initialize(
                helper,
                Monitor);

            //----------------------------------------
            // Previous Home記録サービス初期化
            //----------------------------------------

            PreviousHomeService.Initialize(
                helper);

            //----------------------------------------
            // Warp暗転オーバーレイ初期化
            //----------------------------------------

            WarpBlackoutOverlayService.Initialize(
                helper);

            //----------------------------------------
            // Dialogue初期化
            //----------------------------------------

            DialogueService.Initialize(
                Monitor);

            //----------------------------------------
            // 配偶者部屋特殊表示物修正初期化
            //----------------------------------------

            SpouseRoomVisualFixService.Initialize(
                helper);

            //----------------------------------------
            // Content Patcher Position Picker
            //----------------------------------------

            ContentPatcherPositionPickerService.Initialize(
                helper,
                Monitor);

            //----------------------------------------
            // Content Patcher PSR Room Presets Button
            //----------------------------------------

            ContentPatcherPsrRoomPresetButtonService.Initialize(
                helper);

            //----------------------------------------
            // FarmHouseセラー入口修正
            //----------------------------------------

            CellarEntranceFixService.Initialize(
                helper,
                Monitor);

            //----------------------------------------
            // Farmhand Map更新補完
            //----------------------------------------

            FarmhandMapRefreshFixService.Initialize(
                helper,
                Monitor);
        }

        //----------------------------------------
        // イベント登録
        //----------------------------------------

        /// <summary>
        /// ゲーム中に使用するSMAPIイベントを登録します。
        /// </summary>
        private void RegisterEvents(
            IModHelper helper)
        {
            //----------------------------------------
            // GameLoop
            //----------------------------------------

            // ゲーム起動完了処理
            helper.Events.GameLoop.GameLaunched
                += OnGameLaunched;

            // BigCraftable Extension - Sleep
            helper.Events.GameLoop.DayStarted
                += BigCraftableSleepActionService.OnDayStarted;

            // GMCM初期更新用
            helper.Events.GameLoop.UpdateTicked
                += OnUpdateTicked;

            // ゲーム内言語変更時にContent Patcher由来の
            // GMCM追加項目を現在の言語で再登録
            helper.Events.Content.LocaleChanged
                += OnLocaleChanged;

            // BigCraftable Extension - Light
            helper.Events.GameLoop.UpdateTicked
                += MachineLightService.OnUpdateTicked;

            // BigCraftable Extension - Idle Wobble
            helper.Events.GameLoop.UpdateTicked
                += MachineIdleWobbleService.OnUpdateTicked;

            // Building Light / Migration
            // BigCraftable Extension - Sleep継続寝床読込
            helper.Events.GameLoop.SaveLoaded
                += OnSaveLoaded;

            // BigCraftable Extension - Sleep継続寝床保存
            helper.Events.GameLoop.Saving
                += OnSaving;

            // 時刻変更処理
            helper.Events.GameLoop.TimeChanged
                += OnTimeChanged;

            // BigCraftable Extension - Idle Effects
            helper.Events.GameLoop.TimeChanged
                += MachineIdleEffectService.OnTimeChanged;

            // BigCraftable Extension - 状態クリア
            helper.Events.GameLoop.ReturnedToTitle
                += OnReturnedToTitle;

            //----------------------------------------
            // Player
            //----------------------------------------

            helper.Events.Player.Warped
                += OnWarped;

            // Cellarマップの再読み込み後に、保存済みの壁紙と床材を復元します。
            helper.Events.GameLoop.UpdateTicked
                += TsCoreDecoratableCellarMapReload.OnUpdateTicked;

            helper.Events.Content.AssetReady
                += TsCoreDecoratableCellarMapReload.OnAssetReady;

            //----------------------------------------
            // Content
            //----------------------------------------

            // Building Providers
            helper.Events.Content.AssetRequested
                += BuildingProviderDataService.OnAssetRequested;

            // Migration
            helper.Events.Content.AssetRequested
                += MigrationDataService.OnAssetRequested;

            // Warp Providers
            helper.Events.Content.AssetRequested
                += WarpProviderDataService.OnAssetRequested;

            // Notification Themes
            helper.Events.Content.AssetRequested
                += NotificationThemeDataService.OnAssetRequested;

            // Dialogues
            helper.Events.Content.AssetRequested
                += DialogueDataService.OnAssetRequested;

            // Recipe Pages
            helper.Events.Content.AssetRequested
                += CustomRecipePageDataService.OnAssetRequested;

            // BigCraftable Extension
            helper.Events.Content.AssetRequested
                += BigCraftableExtensionDataService.OnAssetRequested;

            // Post Renovation Patch
            helper.Events.Content.AssetRequested
                += PostRenovationPatchDataService.OnAssetRequested;

            // PSR Room Presets
            // Content PatcherからPreset定義を登録する
            // TsCore/PsrRoomPresets Data Assetを提供
            helper.Events.Content.AssetRequested
                += PsrRoomPresetDataService.OnAssetRequested;

            // Custom Flooring
            helper.Events.Content.AssetRequested
                += CustomFlooringDataService.OnAssetRequested;

            // Position Picker
            // Content PatcherからPosition Picker定義を登録する
            // TsCore/PositionPickers Data Assetを提供
            helper.Events.Content.AssetRequested
                += PositionPickerDataService.OnAssetRequested;

            // Mod Conflict Warnings
            helper.Events.Content.AssetRequested
                += ModConflictWarningDataService.OnAssetRequested;

            // PSR Room Presets GMCM Button
            // Content PatcherからGMCMボタン定義を登録する
            // TsCore/PsrRoomPresetButtons Data Assetを提供
            helper.Events.Content.AssetRequested
                += PsrRoomPresetButtonDataService.OnAssetRequested;

            helper.Events.Content.AssetReady
                += BigCraftableExtensionDataService.OnAssetReady;

            helper.Events.Content.AssetReady
                += OnAssetReady;
        }

        //----------------------------------------
        // 配偶者をルーム順で取得
        //----------------------------------------

        /// <summary>
        /// 現在の配偶者を、部屋配置などで使用する順序に並べて返します。
        /// </summary>
        private IEnumerable<string> GetOrderedPartners()
        {
            return service
                .GetRoomOrderedPartners()
                ?? Enumerable.Empty<string>();
        }

        //----------------------------------------
        // GameLaunched
        //----------------------------------------

        /// <summary>
        /// ゲーム起動完了時の初期化処理を行います。
        /// </summary>
        private void OnGameLaunched(
            object? sender,
            GameLaunchedEventArgs e)
        {
            hasGameLaunched = true;

            MarriageApiInitializer.Initialize(
                Helper.ModRegistry,
                Monitor,
                provider);

            RegisterContentPatcherTokens();

            // タイトル画面でModの重複インストールを警告
            ModConflictWarningService.Initialize(Helper, Monitor);

            //----------------------------------------
            // T's Core GMCM登録
            //----------------------------------------

            GenericModConfigMenuService.Register(
                Helper,
                Monitor,
                ModManifest,
                getConfig: () => Config,
                setConfig: config => Config = config);

            //----------------------------------------
            // Content Patcher自身のGMCM初期登録後に
            // T's Core独自のGMCM表示条件を反映
            //----------------------------------------

            refreshContentPatcherConfigMenus =
                true;

            // Content Patcher側のToken/i18n更新が起動直後のtickで完了するため、
            // Position Picker Data Assetの初回取得を1tick遅らせます。
            refreshContentPatcherConfigMenusDelayTicks =
                1;
        }

        //----------------------------------------
        // UpdateTicked
        // Content Patcher GMCM初期更新用
        //----------------------------------------

        /// <summary>
        /// ゲームの更新tickごとに必要なT's Coreの処理を実行します。
        /// </summary>
        private void OnUpdateTicked(
            object? sender,
            UpdateTickedEventArgs e)
        {
            //----------------------------------------
            // 起動時GMCM更新待ち
            //----------------------------------------

            if (!refreshContentPatcherConfigMenus)
                return;

            if (refreshContentPatcherConfigMenusDelayTicks > 0)
            {
                refreshContentPatcherConfigMenusDelayTicks--;
                return;
            }

            refreshContentPatcherConfigMenus =
                false;

            //----------------------------------------
            // Position Picker Data Asset更新
            //----------------------------------------

            // Content PatcherのToken/i18n初期化後に再生成することで、
            // CP側の {{i18n:...}} を解決した状態でGMCMへ登録します。
            Helper.GameContent.InvalidateCache(
                PositionPickerDataService.AssetName);

            Helper.GameContent.InvalidateCache(
                PsrRoomPresetButtonDataService.AssetName);

            //----------------------------------------
            // T's Core GMCM表示条件反映
            //----------------------------------------

            ContentPatcherReloadService
                .RefreshConfigMenus(
                    Helper,
                    Monitor);

            //----------------------------------------
            // 起動時の1回だけ使用
            //----------------------------------------

            Helper.Events.GameLoop.UpdateTicked
                -= OnUpdateTicked;
        }

        //----------------------------------------
        // LocaleChanged
        //----------------------------------------

        /// <summary>
        /// ゲーム内言語変更時にContent Patcher由来の
        /// T's Core GMCM追加項目を現在の言語で再登録します。
        /// </summary>
        private void OnLocaleChanged(
            object? sender,
            LocaleChangedEventArgs e)
        {
            // Position Picker / PSR Room Preset ButtonのData Assetには
            // Content Patcherで解決済みのi18n文字列が入るため、
            // 言語変更後に再生成してからGMCMを再登録します。
            Helper.GameContent.InvalidateCache(
                PositionPickerDataService.AssetName);

            Helper.GameContent.InvalidateCache(
                PsrRoomPresetButtonDataService.AssetName);

            // GameLaunched以前はContent PatcherのContentPacksが
            // 未初期化のため、起動後の既存遅延更新に任せます。
            // ゲーム中の言語変更は従来どおり即時更新します。
            if (hasGameLaunched && !refreshContentPatcherConfigMenus)
            {
                ContentPatcherReloadService
                    .RefreshConfigMenus(
                        Helper,
                        Monitor);
            }

            // 言語変更後のCJBワープ表示名でRegistryを更新します。
            CjbCheatsMenuWarpService.RegisterWarpShortcuts(
                Helper,
                Monitor);
        }

        //----------------------------------------
        // SaveLoaded
        //----------------------------------------

        /// <summary>
        /// セーブデータ読み込み完了時に必要な初期化・再登録処理を行います。
        /// </summary>
        private void OnSaveLoaded(
            object? sender,
            SaveLoadedEventArgs e)
        {
            // SaveLoaded時点で現在の言語が確定しているため、
            // TsCore内蔵Shortcutの表示名を現在のi18nで更新します。
            ShortcutPanelService.RegisterBuiltInShortcuts();

            // CJBのWarpアセットは現在の言語が確定してから読み込みます。
            // 起動直後に読み込むとCJB本体側の表示まで英語でキャッシュされるため、
            // 保存済みCJB Warp Shortcutの復元登録はSaveLoaded後に行います。
            CjbCheatsMenuWarpService.RegisterWarpShortcuts(
                Helper,
                Monitor);

            //----------------------------------------
            // BigCraftable Extension
            // Sleep継続寝床読込
            //----------------------------------------

            BigCraftableSleepPersistenceService.Load();

            //----------------------------------------
            // Building Migration
            //----------------------------------------

            BuildingMigrationService
                .ApplyMigrations(
                    Monitor);

            //----------------------------------------
            // Building Light
            //----------------------------------------

            BuildingLightService
                .UpdateLights();
        }

        //----------------------------------------
        // Saving
        //----------------------------------------

        /// <summary>
        /// セーブ実行時に必要な保存前処理を行います。
        /// </summary>
        private void OnSaving(
            object? sender,
            SavingEventArgs e)
        {
            //----------------------------------------
            // BigCraftable Extension
            // Sleep継続寝床保存
            //----------------------------------------

            BigCraftableSleepPersistenceService.Save();
        }

        //----------------------------------------
        // ReturnedToTitle
        //----------------------------------------

        /// <summary>
        /// タイトル画面へ戻った時に、セーブ固有の状態をリセットします。
        /// </summary>
        private void OnReturnedToTitle(
            object? sender,
            ReturnedToTitleEventArgs e)
        {
            //----------------------------------------
            // BigCraftable Extension
            //----------------------------------------

            MachineActionEffectService.Clear();

            MachineActionWobbleService.Clear();

            MachineIdleWobbleService.Clear();

            MachineAnimationTextureService.Clear();

            MachineLightService.Clear();

            BigCraftableSleepActionService.Clear();

            BigCraftableSleepPersistenceService.Clear();

            BigCraftableExtensionTextureService.Clear();

            BigCraftableExtensionDataService.Clear();
        }

        //----------------------------------------
        // TimeChanged
        //----------------------------------------

        /// <summary>
        /// ゲーム内時刻が変化した時に必要な処理を実行します。
        /// </summary>
        private void OnTimeChanged(
            object? sender,
            TimeChangedEventArgs e)
        {
            BuildingLightService
                .UpdateLights();
        }

        //----------------------------------------
        // Warped
        //----------------------------------------

        /// <summary>
        /// プレイヤーが別ロケーションへ移動した時に必要な処理を実行します。
        /// </summary>
        private void OnWarped(
            object? sender,
            WarpedEventArgs e)
        {
            if (!e.IsLocalPlayer)
                return;

            //----------------------------------------
            // Building Light
            //----------------------------------------

            BuildingLightService
                .UpdateLights();

            // 保存済みの壁紙を、移動先Cellarの現在のマップへ再適用します。
            TsCoreDecoratableCellarRestore.RestoreSavedWallpaper(e.NewLocation);
        }

        //----------------------------------------
        // AssetReady
        //----------------------------------------

        /// <summary>
        /// ゲームアセットの読み込み完了時に、対象アセットに必要な処理を行います。
        /// </summary>
        private void OnAssetReady(
            object? sender,
            AssetReadyEventArgs e)
        {
            if (!Context.IsWorldReady)
                return;

            if (!e.NameWithoutLocale
                .IsEquivalentTo(
                    "Data/Buildings"))
            {
                return;
            }

            BuildingLightService
                .UpdateLights();
        }

        //----------------------------------------
        // Content Patcher Token登録
        //----------------------------------------

        /// <summary>
        /// Content Patcherから利用できるT's Core独自トークンを登録します。
        /// </summary>
        private void RegisterContentPatcherTokens()
        {
            var api =
                Helper.ModRegistry
                    .GetApi<IContentPatcherAPI>(
                        "Pathoschild.ContentPatcher");

            if (api == null)
            {
                Monitor.Log(
                    "Content Patcher not found.",
                    LogLevel.Error);

                return;
            }

            TokenRegistrar.Register(
                api,
                ModManifest,
                Helper,
                service,
                GetOrderedPartners);
        }
    }
}
